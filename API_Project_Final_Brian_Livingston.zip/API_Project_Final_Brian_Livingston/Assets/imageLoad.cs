﻿// Add this script to a GameObject. The Start() function fetches an
// image from the documentation site.  It is then applied as the
// texture on the GameObject.

using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections.Generic;

public class imageLoad : MonoBehaviour
{
    public SpriteRenderer thisSpriteRender;
    public RawImage thisRawImage;
    public Material imageMaterial;
    public string url = "https://cdn.amctheatres.com/production/2/movies/50700/50740/HeroDesktopDynamic/67708.jpg";


    IEnumerator Start()

    {
        Texture2D tex;
        tex = new Texture2D(4, 4, TextureFormat.DXT1, false);
        using (WWW www = new WWW(url))
        {
            yield return www;
            www.LoadImageIntoTexture(tex);
            GetComponent<Renderer>().material.mainTexture = tex;

            imageMaterial = thisSpriteRender.material;

            yield return new WaitForSeconds(1);

            thisRawImage.material = imageMaterial;
        }
    }
}
          
