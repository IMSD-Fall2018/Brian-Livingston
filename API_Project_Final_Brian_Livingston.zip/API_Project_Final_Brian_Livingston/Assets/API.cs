﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System;

public class API : MonoBehaviour {
    private const string url = "https://api.amctheatres.com/v2/movies/views/now-playing";
    private const string url1 = "https://api.amctheatres.com/v2/movies/views/now-playing";
    private const string AMC_API_Key = "4BD0533F-CD8C-44F8-9A1E-5D8A75C44F7D";

    public Image img;
    public SpriteRenderer thisSpriteRender;
    public RawImage thisRawImage;
    public Material imageMaterial;

    //https://api.amctheatres.com/v2/media/images/sizes?content-type=Poster
    //https://cdn.amctheatres.com/production/2/movies/50700/50740/HeroDesktopDynamic/67708.jpg

    public Text responseText;
    
    
    public void Request()
    {
        
        WWWForm form = new WWWForm();

        Dictionary<string, string> headers = form.headers;
        headers["X-AMC-Vendor-Key"] = AMC_API_Key;
        WWW request = new WWW(url,null,headers);
        StartCoroutine(OnResponse(request));
        
        
    }

    public IEnumerator OnResponse(WWW req)
    {
        

        yield return req;

        
        responseText.text = req.text;
       // Debug.Log(req.text);
        JSONObject tempData = new JSONObject(req.text);
        //Debug.Log(tempData);
        JSONObject MovieType = tempData["_embedded"]["movies"][0]["media"]["posterDynamic"];
        
        Debug.Log(MovieType);
        img.sprite = Sprite.Create(req.texture, new Rect(0, 0, req.texture.width, req.texture.height), new Vector2(), 0, 0);

    }
     
    



}
