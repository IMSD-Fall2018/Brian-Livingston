﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GetMovieImage : MonoBehaviour {
    public GameObject image;

    public string url = "https://api.amctheatres.com/v2/media/images/sizes?content-type=Poster";

    IEnumerator Start()
    {

        // fetch the actual info, like you would from a browser
        WWW www = new WWW(url);

        // yield return waits for the download to complete before proceeding
        // but since this is in IEnumerator it wont stall the program outright
        yield return www;

        // use a JSON Object to store the info temporarily
        // this makes it easy to access the data struture
        JSONObject tempData = new JSONObject(www.text);

        // this particular API stores all the data under the header
        // "consolidated_weather" so first get in there
        JSONObject movieDetails = tempData["contentTypes"];

        // log it just to see whats up
        NewMethod(movieDetails);

        // now we can do cool stuff like...
        string MovieType = movieDetails[0]["_embedded"]["movies"][0]["media"]["posterDynamic"].str;
        Debug.Log(MovieType);


        // depending on which type of weather,
        // activate that game
        //if (WeatherType == "Heavy Cloud") {
        //HeavyCloud.SetActive (true);
        //}

        //if (WeatherType == "Light Cloud") {
        //LightCloud.SetActive (true);
        //}
    }

    private static void NewMethod(JSONObject movieDetails)
    {
        Debug.Log(movieDetails.ToString());
    }
}

